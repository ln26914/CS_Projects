
/**
 * A Checking Account Class
 * Just like a bank account, except limited to -$100 balance and tracks
 * deposit fees.
 * 
 * References:
 * Gaddis, T. (2015). Starting Out With Java Myprogramming Lab 
 * From Control Structures Through Objects. (6th ed.). Addison-Wesley. 
 *
 * @author Noah Boyd
 * @version v0.1 (July 14th, 2024)
 */
public class CheckingAccount extends Account { // is-a Account
    
    // Instance Variables
    private double minBalance = -100; // Minimum balance in the account
    private int deposits = 0; // Deposit counter for fee charging
    
    /**
     * Constructor:
     * Create objects of type CheckingAccount
     */
    public CheckingAccount(int accountNumber, double interestRate) {
        super(accountNumber, interestRate);
        this.balance = 0.00;
    }
    
    /**
     * getDeposits
     * Returns the number of deposits from this account.
     */
    public int getDepositCount() {
        return this.deposits;
    }
    
    /**
     * Withdraw:
     * 
     * Override:
     * Withdraw an amount that's less than or equal to this account's balance
     */
    @Override
    public void withdraw(double amount) {
        if(amount <= this.balance - minBalance) {
            // Balance is at least the amount. Withdraw Possible.
            // Minimum balance is -100.
            this.withdraw(amount);
        } else {
            // Insufficient Balance. Withdraw Impossible.
            // Do Nothing
        }
    }
    
    /**
     * ProcessEndOfMonth
     * Add interest from the end of this month.
     * Override: Reset withdrawal count.
     */
    @Override
    public void processEndOfMonth() {
        double interestAmount = (interestRate/100) * (1/12) * this.balance;
        this.deposit(interestAmount);
        this.withdraw(this.getDepositCount() * 2); // $2 deposit fee for each deposit.
    }
}
