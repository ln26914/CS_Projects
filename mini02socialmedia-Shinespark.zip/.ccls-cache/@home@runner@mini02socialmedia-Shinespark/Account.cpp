#include <iostream>
#include <iomanip>
#include <sstream>
#include "Account.h"
#include "library.h"

using namespace std;

/*
class Account {
  private:
    string username_;
    string password_;
    string following_[20]; //to store the usernames of all accounts followed by the current account owner
    unsigned nFollowing_;  //number of people followed by this account
  public:
    //constructors
    Account(const string& username);

    //Accessors
    string get_following(const string& key = "") const; 
    string to_string() const;

    //mutator
    bool follow(const string& username);
    bool unfollow(const string& username);
};
*/

Account::Account(const string& username) {
    this->username_ = username;
    this->password_ = random_string();

    for(int i = 0; i < 20; i++) {
        this->following_[i] = " ";
    }
    nFollowing_ = 0;
}

string Account::get_following(const string& key) const{
    bool search = false;
    if(key != "") search = true;
    stringstream str("");
    str << left;
    str << this->username_ << "'s following containing \"" << key << "\":\n";
    for(int i = 0; i < 20; i++) {
        if(this->following_[i] != " ") {
            if(search) {
                for(int c = 0; c < this->following_[i].length(); c++) {
                    string guess = this->following_[i].substr(c,key.length());
                    if(guess == key) {
                        str << "\t" << this->following_[i] << "\n";
                        break;
                    }
                }
            } else
                str << "\t" << this->following_[i] << "\n";
        }
    }
    str << "\n";

    return str.str();
}

//Show the account data
string Account::to_string() const {
    stringstream str("");
    str << "Username: " << this->username_ << " "
        << "Password: " << this->password_ << " "
        << "Following " << nFollowing_ << " users.";
    
    return str.str();
}

bool Account::follow(const string& username) {
    for(int i = 0; i < this->nFollowing_; i++) {
        if(username == this->following_[i])
            return false;
    }
    
    this->following_[nFollowing_] = username;
    this->nFollowing_++;
    return true;
}

bool Account::unfollow(const string& username) {
    for(int i = 0; i < this->nFollowing_; i++) {
        if(username == this->following_[i]) {
            for(int j = i; j < this->nFollowing_; j++) {
                this->following_[j] = this->following_[j+1]; 
            }
            this->nFollowing_--;
            return true;
        }
    }
    return false;
}