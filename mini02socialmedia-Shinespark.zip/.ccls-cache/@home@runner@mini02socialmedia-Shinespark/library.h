#include <sstream>

using namespace std;

#ifndef library_h
#define library_h
// Function prototypes

void nl(
	int lines = 1); // Produce new lines. 1 by default

string random_string(int length = 10);

#endif