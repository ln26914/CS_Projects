#include <iomanip>
#include <iostream>
#include <sstream>

#include "Account.h"
#include "library.h"

using namespace std;

int main() {
    srand(time(NULL));
	// Define variables
    //5x specific constructor code
	Account Accounts[5] = {Account("JDBoyd"),
						   Account("LCastillo"),
						   Account("DanWaur"),
						   Account("YASHASWI!!"),
						   Account("SlackharpTV")};

    string following_pool[5] = {"ShinesparkTV","Joseph Joestar","average reddit moderator","The_Gigachad","Merlin"};
	/*
	Account Inspirations:
	JDBoyd: My father, a software engineer at Qualcomn
	LCastillo: my CS111 professor in Fall 2022
	DanWaur: My best friend and fellow computer scientist
	YASHASWI!!: Another computer scientist friend
	SlackharpTV: Another computer scientist friend
	*/

    
    //Test follow() and to_string();
    for(int i = 0; i < 5; i++) {
        for(int j = 0; j < 5; j++)
            Accounts[i].follow(following_pool[j]);
        
        //cout << Accounts[i].to_string() << endl;
    }
    /*
    //cout << endl << endl << endl;
    
    //Test get_following()
    
    for(int i = 0; i < 5; i++) {
        cout << Accounts[i].get_following() << endl;
    }
    
    cout << Accounts[3].get_following("er"); // 2 matches
    cout << Accounts[2].get_following("aa"); // 0 matches
    cout << Accounts[4].get_following("oe"); // 1 match
    cout << Accounts[1].get_following(); // no key provided

    
    
    //Test unfollow()
    //Accounts[0].follow("Gordan Ramsay");
    cout << Accounts[0].get_following() << endl;
    Accounts[0].unfollow("Gordan Ramsay");
    cout << Accounts[0].get_following() << endl;

    */

    //Test follow()
    cout << Accounts[4].get_following() << endl;
    Accounts[4].follow("Rohan Kishibe");
    cout << Accounts[4].get_following() << endl;
    
}