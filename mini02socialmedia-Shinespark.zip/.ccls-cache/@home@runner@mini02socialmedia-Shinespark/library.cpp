//Function definitions for library.h

#include <iostream>
#include <iomanip>
#include <sstream>
#include "library.h"

using namespace std;

void nl(int lines) {
    //One newline by default
    for(int i = 0; i < lines; i++) {
        cout << "\n";
    }
}

string random_string(int length) {

    //Doesn't guarantee a number, a letter, and a capital. However, the order of the characters is completely unpredictable
    char SYMBOLS[3][30] = {
{'a','b','c','d','e','f','g','h','i','j','k','l','m','n','o','p','q','r','s','t','u','v','w','x','y','z'},{'A','B','C','D','E','F','G','H','I','J','K','L','M','N','O','P','Q','R','S','T','U','V','W','X','Y','Z'},{'1','2','3','4','5','6','7','8','9','0'},
}; // SYMBOLS[0] is lowercase, SYMBOLS[1] is uppercase, SYMBOLS[2] is numerical, SYMBOLS[3] is non-alphanumeric

    int LENGTHS[3] = {26,26,10}; //LENGTHS indicates the length of the SYMBOLS array.
    int COUNTS[3] = {0,0,0};
    
    char c; // Character to be appended to our password
    int q = 0, r = 0; //2 random indexes
    string output = ""; //Password to be created

    password_generation:
    for(int i = 0; i < length; i++) {
        q = rand() % 3;
        r = rand() % LENGTHS[q];
        c = SYMBOLS[q][r];
        output+=c;
        COUNTS[q]++;
    }

    //If for some reason the password fails the "aA0" requirement, generate a new one
    for(int i = 0; i < 3; i++) {
        if(!COUNTS[i]) goto password_generation;
    }

    //Return the password
    return output;
}