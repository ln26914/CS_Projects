#include <iostream>
#include "PercentageCoupon.h"

using namespace std;

int main() {
    Date dates[13] = {Date(3),Date(33),Date(63),Date(93),Date(123),Date(153),Date(183),Date(213),Date(243),Date(273),Date(303),Date(333),Date(363)};

    for(int i = 0; i < 13; i++) {
        cout << dates[i].to_string() << endl;
    }

    Date d;
    d = "06/24";
    cout << "06/24" << endl;
    cout << "Date d: " << d << endl;


    
    Coupon coupons[6] = {Coupon("01/05",5.00), Coupon("03/08",15.00), Coupon("03/15",50.00),Coupon("08/08",8.00),Coupon("02/08",25.00),Coupon("03/03",50.00)};
    Date today;
    today = "03/08";
    cout << "Today: " << today << endl;

    double order = 825.00;
    cout << "Order: $" << order << endl;
    for(int i = 0; i < 6; i++) {
        cout << coupons[i].to_string() << endl;
        order = coupons[i].apply(today.to_string(),order);
        cout << "New Total: " << order << endl;
    }
    cout << "-------------------------------------" << endl;

    PercentageCoupon percentageCoupons[4] = {PercentageCoupon("02/16",25),PercentageCoupon("05/25",15),PercentageCoupon("09/27",10),PercentageCoupon("03/08",50)};
    double order2 = 1000.00;
    cout << "Order: $ " << order2 << endl;

    for(int i = 0; i < 4; i++) {
        cout << percentageCoupons[i].to_string() << endl;
        order2 = percentageCoupons[i].apply(today.to_string(),order2);
        cout << "New Total: " << order2 << endl;
    }
    
}