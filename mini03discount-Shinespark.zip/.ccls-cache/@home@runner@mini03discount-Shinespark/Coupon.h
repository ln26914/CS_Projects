#include "Date.h"
#include <iostream>

using namespace std;

class Coupon {
    protected:
        Date expiration_;
        double discount_;
      //  bool has_expired(const String&) const;

    public:
        Coupon(const string& date, double fl); 
        double apply(const string& str, double fl) const; 
        string to_string(); 
        bool has_expired(const string& date) const ; 

};