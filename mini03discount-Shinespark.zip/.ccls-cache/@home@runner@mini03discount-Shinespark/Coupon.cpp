#include "Coupon.h"
#include <iostream>
#include <sstream> 
#include <string>

using namespace std;

/*
class Coupon {
    protected:
        Date expiration_
        double discount_
        bool has_expired(const String&) const;

    public:
        Coupon(const String&, double);
        double apply(const String&, double) const;
        string to_string() const;

};
*/

 Coupon::Coupon(const string& date, double fl){
    this->expiration_ = date;
    this->discount_ = fl;
} // Constructor 

  double Coupon::apply(const string& str, double fl) const {
    if(!this->has_expired(str)) {
        fl -= this->discount_;
    }
    
    return fl;
} // apply function 

 string Coupon::to_string() {
    stringstream str("");
    str << "The Coupon is $" << this->discount_ << " off by " << this->expiration_;

    return str.str();
}

bool Coupon::has_expired(const string& date) const {
    Date rhs;
    rhs = date;

    Date lhs;
    lhs = this->expiration_;

    if(lhs > rhs) {
        return false;
    }
    else return true;
    
}