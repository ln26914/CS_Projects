#include "Coupon.h"

class PercentageCoupon : public Coupon {
    public:
        PercentageCoupon(const string& date, unsigned percent);
        double apply(const string&, double) const;
        string to_string(); 
};