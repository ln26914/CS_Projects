#include "Date.h"
#include <iostream>
#include <sstream>
using namespace std;

Date::Date() : days_(0) {
}

Date::Date(unsigned days) : days_(days) {
}

string Date::to_string() {
	stringstream output("");

    int day = 1;
    int tempdays = this->days_;
    int month = 1;

    int i = 0;
    for(int i = 0; i < 12; i++) {
        if ((tempdays % this->months[i]) < tempdays) {
            month++;
            tempdays -= this->months[i];
        }
    }
    day += tempdays;

    if(month < 10)
        output << "0";
	output << month << "/";
    if(day < 10)
        output << "0";
    output << day << " is " << this->days_ << " days from January 1";
	return output.str();
}

Date Date::operator=(const string &rhs) {
	int month = stoi(rhs.substr(0, 2)) - 1;
    int day = stoi(rhs.substr(3, 2)) - 1;
	this->days_ = 0;
	for (int i = 0; i < month; i++) {
		day += months[i];
	}
	this->days_ += day;

	return *this;
}

bool Date::operator>(const Date &d) {
	if (d.days_ < this->days_)
		return true;
	else
		return false;
}

ostream& operator<<(ostream &os, Date &d) {


    int day = 1;
    int tempdays = d.days_;
    int month = 1;

    int i = 0;
    for(int i = 0; i < 12; i++) {
        if ((tempdays % d.months[i]) < tempdays) {
            month++;
            tempdays -= d.months[i];
        }
    }
    day += tempdays;
    
	os << month << "/" << day;
    
	return os;
}