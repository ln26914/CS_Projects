#ifndef DATE_H
#define DATE_H
#include <iostream>
#include <string>
#include <sstream>
using namespace std;

class Date {
    private:
        unsigned days_;
        constexpr const static int months[] = {31,28,31,30,31,30,31,31,30,31,30,31};
    public:
        Date();
        Date(unsigned);
        Date(string);
        string to_string();
        Date operator=(const string& rhs);
        bool operator>(const Date& rhs);
        
        friend ostream& operator<<(ostream&, Date&);
};

#endif