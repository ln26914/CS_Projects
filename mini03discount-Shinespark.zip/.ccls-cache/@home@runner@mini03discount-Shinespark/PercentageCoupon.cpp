#include <iostream>
#include <sstream>
#include <math.h>
#include "PercentageCoupon.h"

/*
class PercentageCoupon public Coupon{
    public:
        PercentageCoupon(const string& date, unsigned percent);
        double apply(const string&, double) const;
        string to_string() const;
};

*/

PercentageCoupon::PercentageCoupon(const string& date, unsigned percent = 0) : Coupon(date, percent) {
    this->expiration_ = date;
    this->discount_ = abs(percent / 100.0);
}

double PercentageCoupon::apply(const string& date, double fl) const {

    if(!this->has_expired(date.substr(0,5))) {
        fl *= (1.0-discount_);
        return fl;
    }
    return fl;
}

string PercentageCoupon::to_string() {
    stringstream str("");

    str << "The Coupon is " << this->discount_*100 << "% off by " << expiration_;

    return str.str();
}